// Copyright 2015 Alec Thilenius
// All rights reserved.

#include "linked_list.h"

#include <iostream>

namespace thilenius {
namespace external {
namespace csci2270 {
namespace assignments {
namespace linked_list {

//  __         __     __   __     __  __     ______     _____
// /\ \       /\ \   /\ "-.\ \   /\ \/ /    /\  ___\   /\  __-.
// \ \ \____  \ \ \  \ \ \-.  \  \ \  _"-.  \ \  __\   \ \ \/\ \
//  \ \_____\  \ \_\  \ \_\\"\_\  \ \_\ \_\  \ \_____\  \ \____-
//   \/_____/   \/_/   \/_/ \/_/   \/_/\/_/   \/_____/   \/____/
//                              __         __     ______     ______   ______
//                             /\ \       /\ \   /\  ___\   /\__  _\ /\  ___\
//                             \ \ \____  \ \ \  \ \___  \  \/_/\ \/ \ \___  \
//                              \ \_____\  \ \_\  \/\_____\    \ \_\  \/\_____\
//                               \/_____/   \/_/   \/_____/     \/_/   \/_____/

// Welcome to assignment two, linked lists! This is a tough one, I'll be honest!
// It will be your first 'real' use of pointers. Try your best to keep your code
// 'clean'. That probably means you'll need to rewrite things a few times as you
// find better ways of doing things. That's how coding actually works, including
// at Google. None of this 'puke on a page and turn it in' stuff like we do in
// our humanities classes :p Done a little elegantly, this assignment can be
// completed in less than 50 lines of code.

// A few tips that will make this assignment way, way easier:
//
//  - Implement each function in the order that they appear in this file, then
//    use the functions you already implemented to write the later ones. For
//    example, (hint hint) maybe Size would be helpful in InsertAtIndex, or
//    (hint hint) maybe InsertAtIndex would be helpful for PushFront
//
//  - When you're stuck, whiteboard out exactly what needs to happen. Chances
//    are your struggle is conceptual, not programmatic. Once you see clearly
//    what to do on a whiteboard, the code will be pretty easy.
//
//  - If you find yourself writing code to test every possible edge case you
//    might want to step back and think of a 'cleaner' way of doing things. I
//    promise, there is one. The less code, the more you thought the problem
//    out, always.
//
//  - Work with your peers! Tossing ideas back and forth is an excellent way to
//    wrap your head around something. No, that doesn't mean ask your peers for
//    the answer because it's the night it's due and you're pretty screwed
//    because the assignment is so hard :)

// The constructor. It needs to set 'head' to 'nullptr'. There are 2 ways to do
// this in a constructor, you can use either.
LinkedList::LinkedList() 
	{
		head = NULL;
	}

// Should return the size of the linked list. You'll need to walk the linked
// list and count nodes to do this.
int LinkedList::Size() 
	{
		int count = 0;
		LinkedListNode* TraverseNode = head;
		while (TraverseNode != NULL)
		{
			count ++;
			TraverseNode = TraverseNode->next_node;
		}
		 return count; 
	}

// Inserts an element at index (so that once inserted it is at that index) into
// the linked list. This is one of the more tricky ones. You'll need to walk the
// list until you find the index you want to insert at (maybe one before that,
// hint hint) and 'wire' in the new element. Whiteboard this one out!!
bool LinkedList::InsertAtIndex(int value, int index) 
	{
		int length = Size();
		//Insert a node at the beginning of an empty list
		if (index == 0 && length == 0)
		{
			LinkedListNode* tmp = new LinkedListNode;
			head = tmp;
			tmp->next_node = nullptr;
			tmp->data = value;
		}
		//Insert a node at the beginning of a list
		if (index == 0 && length != 0)
		{
			LinkedListNode* tmp = new LinkedListNode;
			tmp->next_node = head;
			head = tmp;
			tmp->data = value;
		}
		//Insert a node in the middle of a list
		if (index < length && index > 0)
		{
			//Create a new node 
			LinkedListNode* tmp = new LinkedListNode;
			LinkedListNode* tmp2 = new LinkedListNode;
			tmp->next_node = head;
			tmp2->next_node = head;
			for (int i=0; i < index; i++)
			{
				tmp2 = tmp2->next_node;
			}
			tmp->next_node = tmp2->next_node;
			tmp2->next_node = tmp;	
			tmp->data = value;
		}
		//Insert a node at the end of a list
		if (index == length && length > 0)
		{
			//Create a new node 
			LinkedListNode* tmp = new LinkedListNode;
			//Make the new node point to nullptr
			tmp->next_node = nullptr;
			//Assign the new node a value
			tmp->data = value;
			//Get the node before temp
			LinkedListNode* tmp2;
			tmp2->next_node = head;
			for (int i = 0; i < index; i++)
			{
				tmp2 = tmp2->next_node;
			}
			tmp2->next_node = tmp;
		}
		std::cout << "Don't forget, you can use cout to debug things! The output "
               "apears ABOVE the test output" << std::endl;
		if (index < 0 || index > length)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

// Adds an element to the front of the linked list. If this one takes you more
// than one or two lines of code then you clearly didn't read the tips above :p
void LinkedList::PushFront(int value) 
{
	InsertAtIndex(value, 0);
}

// Adds an element to the end of the linked list. If this one takes you more
// than one or two lines of code then you clearly didn't read the tips above :p
void LinkedList::PushBack(int value) 
{
	int length = Size();
	InsertAtIndex(value, length);
}

// This is the subscript operator. It allows the user of your code to access the
// nth element by just using the array operator, like this:
// std::cout << "The third element in the list is: " << my_linked_list[2];
// It takes in the index of the item the user wants to get at, and returns the
// item at that index (as a reference).
int& LinkedList::operator[](int index) 
{
	int count = 0;
	LinkedListNode* TraverseNode = head;
	while (count != index)
	{
		count ++;
		TraverseNode = TraverseNode->next_node;
	}
	return TraverseNode->data;
}

// Removes an item at the given index. This means you'll need to walk the list
// until you get to that index (or one before it, hint hint), and remove that
// item by 'wiring' the next_node to skip that item. You'll also need to call
// delete on that item to free the memory back to the OS.
bool LinkedList::RemoveAtIndex(int index)
{
	int length = Size();
	//Account for non-existant index
	if (index == length || head == NULL || index < 0)
	{
		return false;
	}
	else
	{
		//The index is 0
		if (index == 0)
		{
			LinkedListNode* tmp = head;
			head = head->next_node;
			delete tmp;
		}
		//The index is in the list
		if (index > 0 && index < (length-1))
		{
			LinkedListNode* tmp = head;
			LinkedListNode* tmp2 = head;
			for (int i = 1; i < index; i++)
			{
				tmp = tmp->next_node;
				tmp2 = tmp2->next_node;
			}
			tmp = tmp->next_node;
			tmp2->next_node = tmp->next_node;
			delete tmp;
		}
		//The index is at the end of the list
		if (index == (length-1) && index != 0)
		{
			LinkedListNode* tmp = head;
			LinkedListNode* tmp2 = head;
			for (int i = 1; i < index; i++)
			{
				tmp = tmp->next_node;
				tmp2 = tmp2->next_node;
			}
			tmp = tmp->next_node;
			tmp2->next_node = tmp->next_node;
			delete tmp;
			tmp2 = nullptr;			
		}
		
		return true;
	}
}

// Should remove all items from the list. If this one takes you more than a few
// lines of code then you clearly didn't read the tips above. Hint hint.
void LinkedList::Clear() 
{
	int length = Size();
	for (int i = length; i >= 0; i--)
	{
		RemoveAtIndex(i);
	}
}

// Extra Credit (worth 5 points)
// Removes all occurrences of 'value' from the list. For example, if I have the
// linked list [0, 1, 1, 1, 2] and I call RemoveAll(1), it should remove the
// middle 3 items, leaving only [0, 2]
void LinkedList::RemoveAll(int value) 
{
	int length = Size();
	LinkedListNode* TraverseNode = head;
	int i = 0;
	while (i < length)
	{
		int tmp = TraverseNode->data;
		
		if (tmp == value)
		{
			RemoveAtIndex(i);
			length = Size();
			TraverseNode = head;
			i = 0;
		}
		
		else
		{
			i++;
			TraverseNode = TraverseNode->next_node;
		}
	}
}

}  // namespace linked_list
}  // namespace assignments
}  // namespace csci2270
}  // namespace external
}  // namespace thilenius
