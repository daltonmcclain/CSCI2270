/*
Dalton Morrow
CSCI 2270 - 102
TA: Apoorva Bapat
Assignment 3

This file is a header file for a queue using an array. It has
an array of length 10, a constructor, an integer indicating
the top of the queue, and members for enqueuing, dequeuing,
and printing the queue.
*/

#include <iostream>

struct QueueArray
{
public:
    QueueArray();
    int data[10];
    int top;
    void enqueue(int value);
    void dequeue();
    void print();
};

QueueArray::QueueArray()
{
    top = 0;
    for (int i = 0; i < 10; i++)
    {
        data[i] = NULL;
    }
}

void QueueArray::enqueue(int value)
{
    if (top > 9)
    {
        std::cout << "your queue is full!" << std::endl;
    }
    else
    {
        std::cout << "ENQUEUEING " << value << std::endl;
        data[top] = value;
        top++;
    }
}

void QueueArray::dequeue()
{
    if (data[0] == NULL)
    {
        std::cout << "The queue is empty!" << std:: endl;
    }
    else
    {
        std::cout << "DEQUEUEING " << data[0] << std::endl;
        for (int i = 0; i < 9; i++)
        {
            data[i] = data[i+1];
        }
        data[9] = 0;
        top--;
    }
}

void QueueArray::print()
{
    std::cout << "The list is:" << std::endl;
    for (int i = 9; i >= 0; i--)
    {
        std::cout << data[i] << std::endl;
    }
}
