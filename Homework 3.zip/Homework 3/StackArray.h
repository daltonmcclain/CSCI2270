/*
Dalton Morrow
CSCI 2270 - 102
TA: Apoorva Bapat
Assignment 3

This file is a header file for a stack using an array. It includes
an array of length 10, a constructor, an integer indicating the
top of the stack, and members for pushing, popping, and printing
the stack.
*/

#include <iostream>

struct StackArray
{
public:
    StackArray();
    int data[10];
    int top;
    void push(int value);
    void pop();
    void print();
};

StackArray::StackArray()
{
    top = 0;
    for (int i = 0; i < 10; i++)
    {
        data[i] = NULL;
    }
}

void StackArray::push(int value)
{
    if (top > 9)
    {
        std::cout << "your stack is full!" << std::endl;
    }
    else
    {
        std::cout << "PUSHING " << value << std::endl;
        data[top] = value;
        top++;
    }
}

void StackArray::pop()
{
    if (data[0] == NULL)
    {
        std::cout << "The stack is empty!" << std::endl;
    }
    else
    {
        std::cout << "POPPING " << data[top-1] << std::endl;
        data[top-1] = NULL;
        top--;
    }
}

void StackArray::print()
{
    std::cout << "The list is:" << std::endl;
    for (int i = 9; i >= 0; i--)
    {
        std::cout << data[i] << std::endl;
    }
}
