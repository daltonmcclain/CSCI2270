/*
Dalton Morrow
CSCI 2270 - 102
TA: Apoorva Bapat
Assignment 3

This is a header file for a linked list. This list includes members
for pushing, popping, enqueueing, and dequeueing in addition to the
constructor, length, insert, remove, and print members. There is a
struct for the node as well as a struct for the linked list.
*/

#include <iostream>

struct Node
{
    int data;
    Node* next_node;
    Node(int data, Node* next_node) :
        data(data), next_node(next_node) {}
    Node() :
        data(0), next_node(NULL) {}
};

struct LinkedList
{
public:
    LinkedList();
    int length();
    bool InsertAtIndex(int value, int index);
    bool RemoveAtIndex(int index);
    int& operator[](int index);
    void print();
    void push(int value);
    void pop();
    void enqueue(int value);
    void dequeue();
    Node* head;
};

LinkedList::LinkedList()
{
	head = NULL;
}

int LinkedList::length()
{
	int count = 0;
		Node* TraverseNode = head;
		while (TraverseNode != NULL)
		{
			count ++;
			TraverseNode = TraverseNode->next_node;
		}
		 return count;
}

bool LinkedList::InsertAtIndex(int value, int index)
{
	int len = length();
	//Insert a node at the beginning of an empty list
		if (index == 0 && len == 0)
		{
			Node* tmp = new Node;
			head = tmp;
			tmp->next_node = NULL;
			tmp->data = value;
		}
		//Insert a node at the beginning of a list
		else if (index == 0 && len != 0)
		{
			Node* tmp = new Node;
			tmp->next_node = head;
			head = tmp;
			tmp->data = value;
		}
		//Insert a node in the middle of a list
		else if (index < (len) && index > 0)
		{
			//Create a new node
			Node* tmp = new Node;
			Node* tmp2 = new Node;
			tmp->next_node = head;
			tmp2->next_node = head;
			for (int i=0; i < index; i++)
			{
				tmp2 = tmp2->next_node;
			}
			tmp->next_node = tmp2->next_node;
			tmp2->next_node = tmp;
			tmp->data = value;
		}
		//Insert a node at the end of a list
		else if (index == len && len > 0)
		{
            //Create a new node
			Node* tmp = new Node;
			//Make the new node point to nullptr
			tmp->next_node = NULL;
			//Assign the new node a value
			tmp->data = value;
			//Get the node before temp
			Node* tmp2;
			tmp2->next_node = head;
			for (int i = 0; i < index; i++)
			{
				tmp2 = tmp2->next_node;
			}
			tmp2->next_node = tmp;
		}
		else if (index < 0 || index >= len)
		{
			return false;
		}
		else
		{
			return true;
		}
}

bool LinkedList::RemoveAtIndex(int index)
{
	int size = length();
	//Account for non-existant index
	if (index == size || head == NULL || index < 0)
	{
		return false;
	}
	else
	{
		//The index is 0
		if (index == 0)
		{
			Node* tmp = head;
			head = head->next_node;
			delete tmp;
		}
		//The index is in the list
		if (index > 0 && index < (size-1))
		{
			Node* tmp = head;
			Node* tmp2 = head;
			for (int i = 1; i < index; i++)
			{
				tmp = tmp->next_node;
				tmp2 = tmp2->next_node;
			}
			tmp = tmp->next_node;
			tmp2->next_node = tmp->next_node;
			delete tmp;
		}
		//The index is at the end of the list
		if (index == (size-1) && index != 0)
		{
			Node* tmp = head;
			Node* tmp2 = head;
			for (int i = 1; i < index; i++)
			{
				tmp = tmp->next_node;
				tmp2 = tmp2->next_node;
			}
			tmp = tmp->next_node;
			tmp2->next_node = tmp->next_node;
			delete tmp;
			tmp2 = NULL;
		}

		return true;
	}
}

int& LinkedList::operator[](int index)
{
	int count = 0;
	Node* TraverseNode = head;
	while (count != index)
	{
		count ++;
		TraverseNode = TraverseNode->next_node;
	}
	return TraverseNode->data;
}

void LinkedList::print()
{
    std::cout << "The list is:" << std::endl;
    int size = length();
    Node* tmp = head;
    for (int i = 0; i < size; i++)
    {
        int x = tmp->data;
        std::cout << x << std::endl;
        tmp = tmp->next_node;
    }
}

void LinkedList::push(int value)
{
    InsertAtIndex(value,0);
    std::cout << "PUSHING " << value << std::endl;
}

void LinkedList::pop()
{
    if (length() == 0)
    {
        std::cout << "The stack is empty!" << std::endl;
    }
    else
    {
        std::cout << "POPPING " << head->data << std::endl;
        RemoveAtIndex(0);
    }
}

void LinkedList::enqueue(int value)
{
    InsertAtIndex(value,0);
    std::cout << "ENQUEUEING " << value << std::endl;
}

void LinkedList::dequeue()
{
    if (length() == 0)
    {
        std::cout << "The queue is empty!" << std::endl;
    }
    else
    {
        int len = 0;
        Node* tmp = head;
        while (tmp->next_node != NULL)
        {
            len++;
            tmp = tmp->next_node;
        }
        std::cout << "DEQUEUEING " << tmp->data << std::endl;
        RemoveAtIndex(len);
    }
}
