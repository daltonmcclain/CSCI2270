/*
Dalton Morrow
CSCI 2270 - 102
TA: Apoorva Bapat
Assignment 3

This is the main file for assignment 3. It uses the header files for
a linked list, a stack using and array, and a queue using an array.
The program takes in user input to indicate whether it should create
a stack or a queue, then takes in user input to indicate if the
structure should be made using an array or a linked list. The array
structures only allow for 10 integers to be stored at a time. Labels
combined with the 'goto' function allow the program to loop to and
present instructions repeatedly.
*/


#include <iostream>
#include <string>
#include "LinkedList.h"
#include "StackArray.h"
#include "QueueArray.h"

int main()
{
	programPrompt:
	std::cout << "Please select an option below:" << std::endl;
	std::cout << "1. Create STACK" << std::endl;
	std::cout << "2. Create QUEUE" << std::endl;
	std::cout << "3. Exit program" << std::endl;
	std::string programSelection;
	std::cin >> programSelection;
	if (programSelection == "1")
    {
        stackPrompt:
        std::cout << "You've selected STACK\nPlease select an option below:\n1. LINKED LIST\n2. ARRAY\n3. Back" << std::endl;
        std::string dsSelection;
        std::cin >> dsSelection;
        if (dsSelection == "1")
        {
            LinkedList myList;
            LinkedListStack:
            std::cout << "You've selected to make a STACK using a LINKED LIST\nPlease select an option below:" << std::endl;
            std::cout << "1. Push\n2. Pop\n3. Print\n4. Exit" << std::endl;
            std::string input;
            std::cin >> input;
            if (input == "1")
            {
                std::cout << "What number would you like to push?" << std::endl;
                int push;
                std::cin >> push;
                myList.push(push);
                goto LinkedListStack;
            }
            else if (input == "2")
            {
                myList.pop();
                goto LinkedListStack;
            }
            else if (input == "3")
            {
                myList.print();
                goto LinkedListStack;
            }
            else if (input == "4")
            {
                return 0;
            }
            else
            {
                std::cout << "That is not a valid selection";
                goto LinkedListStack;
            }
        }
        else if (dsSelection == "2")
        {
            StackArray myArray;
            ArrayStack:
            std::cout << "You've selected to make a STACK using an ARRAY\nPlease select an option below:" << std::endl;
            std::cout << "1. Push\n2. Pop\n3. Print\n4. Exit" << std::endl;
            std::string input;
            std::cin >> input;
            if (input == "1")
            {
                std::cout << "What number would you like to push?" << std::endl;
                int push;
                std::cin >> push;
                myArray.push(push);
                goto ArrayStack;
            }
            else if (input == "2")
            {
                myArray.pop();
                goto ArrayStack;
            }
            else if (input == "3")
            {
                myArray.print();
                goto ArrayStack;
            }
            else if (input == "4")
            {
                return 0;
            }
            else
            {
                std::cout << "That is not a valid selection";
                goto ArrayStack;
            }
        }
        else if (dsSelection == "3")
        {
            goto programPrompt;
        }
        else
        {
            std::cout << "That is not a valid selection" << std::endl;
            goto stackPrompt;
        }
    }
    else if (programSelection == "2")
    {
        queuePrompt:
        std::cout << "You've selected QUEUE\nPlease select an option below:\n1. Linked List\n2. Array\n3. Back" << std::endl;
        std::string dsSelection;
        std::cin >> dsSelection;
        if (dsSelection == "1")
        {
            LinkedList myList;
            LinkedListQueue:
            std::cout << "You've selected to make a QUEUE using a LINKED LIST\nPlease select an option below:" << std::endl;
            std::cout << "1. Enqueue\n2. Dequeue\n3. Print\n4. Exit" << std::endl;
            std::string input;
            std::cin >> input;
            if (input == "1")
            {
                std::cout << "What number would you like to enqueue?" << std::endl;
                int enqueue;
                std::cin >> enqueue;
                myList.enqueue(enqueue);
                goto LinkedListQueue;
            }
            else if (input == "2")
            {
                myList.dequeue();
                goto LinkedListQueue;
            }
            else if (input == "3")
            {
                myList.print();
                goto LinkedListQueue;
            }
            else if (input == "4")
            {
                return 0;
            }
            else
            {
                std::cout << "That is not a valid selection" << std::endl;
                goto LinkedListQueue;
            }
        }
        else if (dsSelection == "2")
        {
            QueueArray myArray;
            ArrayQueue:
            std::cout << "You've selected to make a QUEUE using an ARRAY\nPlease select an option below:" << std::endl;
            std::cout << "1. Enqueue\n2. Dequeue\n3. Print\n4. Exit" << std::endl;
            std::string input;
            std::cin >> input;
            if (input == "1")
            {
                std::cout << "What number would you like to enqueue?" << std::endl;
                int enqueue;
                std::cin >> enqueue;
                myArray.enqueue(enqueue);
                goto ArrayQueue;
            }
            else if (input == "2")
            {
                myArray.dequeue();
                goto ArrayQueue;
            }
            else if (input == "3")
            {
                myArray.print();
                goto ArrayQueue;
            }
            else if (input == "4")
            {
                return 0;
            }
            else
            {
                std::cout << "That is not a valid selection" << std::endl;
                goto ArrayQueue;
            }
        }
        else if (dsSelection == "3")
        {
            goto programPrompt;
        }
        else
        {
            std::cout << "That is not a valid selection" << std::endl;
            goto queuePrompt;
        }
    }
    else if (programSelection == "3")
    {
        std::cout << "You've selected EXIT" << std::endl;
    }
    else
    {
        std::cout << "That is not a valid selection" << std::endl;
        goto programPrompt;
    }
}
